package com.dropwizard.gameauth;

public class Gameauth {

}
