package com.dropwizard.gameauth;

import io.dropwizard.Application;
import io.dropwizard.setup.Bootstrap;
import io.dropwizard.setup.Environment;

public class GameauthApplication extends Application<GameauthConfiguration> {

    public static void main(final String[] args) throws Exception {
        new GameauthApplication().run(args);
    }

    @Override
    public String getName() {
        return "Gameauth";
    }

    @Override
    public void initialize(final Bootstrap<GameauthConfiguration> bootstrap) {
    	environment.jersey().register(new GameUserRESTController());
    }

    @Override
    public void run(final GameauthConfiguration configuration,
                    final Environment environment) {
    	final Client demoRESTClient = new JerseyClientBuilder(environment).build("DemoRESTClient");
    }

}
